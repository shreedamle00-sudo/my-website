// Chart.js configurations for model performance visualization
class ModelCharts {
    constructor() {
        this.init();
    }
    
    init() {
        // Wait for DOM to be fully loaded
        document.addEventListener('DOMContentLoaded', () => {
            this.createDatasetChart();
            this.createPerformanceChart();
        });
    }
    
    createDatasetChart() {
        const ctx = document.getElementById('datasetChart');
        if (!ctx) return;
        
        const datasetData = {
            labels: ['Angry', 'Calm', 'Disgust', 'Fearful', 'Happy', 'Neutral', 'Sad', 'Surprised'],
            datasets: [{
                label: 'Number of Samples',
                data: [192, 192, 192, 192, 192, 96, 192, 192],
                backgroundColor: [
                    '#EF4444', // Red for angry
                    '#06B6D4', // Cyan for calm  
                    '#8B5CF6', // Purple for disgust
                    '#F59E0B', // Amber for fearful
                    '#10B981', // Emerald for happy
                    '#6B7280', // Gray for neutral
                    '#3B82F6', // Blue for sad
                    '#EC4899'  // Pink for surprised
                ],
                borderColor: [
                    '#DC2626',
                    '#0891B2', 
                    '#7C3AED',
                    '#D97706',
                    '#059669',
                    '#4B5563',
                    '#2563EB',
                    '#DB2777'
                ],
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false,
            }]
        };
        
        const config = {
            type: 'bar',
            data: datasetData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'RAVDESS Dataset Distribution',
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    },
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed.y} samples`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#E5E7EB'
                        },
                        ticks: {
                            font: {
                                size: 12
                            }
                        },
                        title: {
                            display: true,
                            text: 'Number of Samples',
                            font: {
                                size: 14
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: 12
                            }
                        }
                    }
                },
                animation: {
                    duration: 1500,
                    easing: 'easeInOutQuart'
                }
            }
        };
        
        new Chart(ctx, config);
    }
    
    createPerformanceChart() {
        const ctx = document.getElementById('performanceChart');
        if (!ctx) return;
        
        const performanceData = {
            labels: ['Angry', 'Calm', 'Disgust', 'Fearful', 'Happy', 'Neutral', 'Sad', 'Surprised'],
            datasets: [
                {
                    label: 'Precision',
                    data: [0.69, 0.70, 0.56, 0.62, 0.63, 0.73, 0.59, 0.70],
                    backgroundColor: 'rgba(59, 130, 246, 0.8)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Recall',
                    data: [0.66, 0.87, 0.58, 0.67, 0.49, 0.42, 0.58, 0.82],
                    backgroundColor: 'rgba(16, 185, 129, 0.8)',
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 2
                },
                {
                    label: 'F1-Score',
                    data: [0.68, 0.78, 0.57, 0.64, 0.55, 0.53, 0.59, 0.75],
                    backgroundColor: 'rgba(245, 158, 11, 0.8)',
                    borderColor: 'rgba(245, 158, 11, 1)',
                    borderWidth: 2
                }
            ]
        };
        
        const config = {
            type: 'radar',
            data: performanceData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Per-Class Performance Metrics',
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            font: {
                                size: 12
                            },
                            padding: 20
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.r.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 1.0,
                        grid: {
                            color: '#E5E7EB'
                        },
                        pointLabels: {
                            font: {
                                size: 12,
                                weight: 'bold'
                            }
                        },
                        ticks: {
                            stepSize: 0.2,
                            font: {
                                size: 10
                            },
                            callback: function(value) {
                                return (value * 100).toFixed(0) + '%';
                            }
                        }
                    }
                },
                animation: {
                    duration: 2000,
                    easing: 'easeInOutQuart'
                },
                elements: {
                    point: {
                        radius: 4,
                        hoverRadius: 6
                    },
                    line: {
                        borderWidth: 2
                    }
                }
            }
        };
        
        new Chart(ctx, config);
    }
}

// Training Progress Animation
class TrainingProgressAnimation {
    constructor() {
        this.init();
    }
    
    init() {
        document.addEventListener('DOMContentLoaded', () => {
            this.observeTrainingSection();
        });
    }
    
    observeTrainingSection() {
        const trainingSteps = document.querySelectorAll('.training-step');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.classList.add('animate-fade-in');
                    }, index * 200);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        });
        
        trainingSteps.forEach(step => {
            observer.observe(step);
        });
    }
}

// Confusion Matrix Visualization
class ConfusionMatrixViz {
    constructor() {
        this.confusionMatrix = [
            [25, 3, 3, 2, 2, 1, 0, 2],  // Angry
            [1, 33, 2, 0, 0, 1, 1, 0],  // Calm
            [5, 2, 22, 3, 2, 0, 2, 2],  // Disgust
            [1, 0, 3, 26, 3, 0, 5, 1],  // Fearful
            [3, 3, 1, 4, 19, 0, 4, 5],  // Happy
            [0, 3, 3, 0, 0, 8, 3, 2],   // Neutral
            [0, 2, 3, 5, 3, 1, 22, 2],  // Sad
            [1, 1, 2, 2, 1, 0, 0, 32]   // Surprised
        ];
        this.emotions = ['Angry', 'Calm', 'Disgust', 'Fearful', 'Happy', 'Neutral', 'Sad', 'Surprised'];
    }
    
    createMatrix() {
        // This would create an interactive confusion matrix
        // Implementation would go here if needed
    }
}

// Performance Metrics Animation
class MetricsAnimation {
    constructor() {
        this.init();
    }
    
    init() {
        document.addEventListener('DOMContentLoaded', () => {
            this.animateMetrics();
        });
    }
    
    animateMetrics() {
        const metricCards = document.querySelectorAll('.metric-card');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateNumber(entry.target);
                }
            });
        }, {
            threshold: 0.5
        });
        
        metricCards.forEach(card => {
            observer.observe(card);
        });
    }
    
    animateNumber(card) {
        const numberElement = card.querySelector('.text-3xl');
        const targetText = numberElement.textContent;
        const isPercentage = targetText.includes('%');
        const targetNumber = parseFloat(targetText.replace('%', '').replace(',', ''));
        
        let currentNumber = 0;
        const increment = targetNumber / 60; // 60 frames for 1 second at 60fps
        
        const animation = () => {
            currentNumber += increment;
            if (currentNumber >= targetNumber) {
                currentNumber = targetNumber;
                if (isPercentage) {
                    numberElement.textContent = currentNumber.toFixed(2) + '%';
                } else {
                    numberElement.textContent = Math.round(currentNumber).toLocaleString();
                }
                return;
            }
            
            if (isPercentage) {
                numberElement.textContent = currentNumber.toFixed(2) + '%';
            } else {
                numberElement.textContent = Math.round(currentNumber).toLocaleString();
            }
            
            requestAnimationFrame(animation);
        };
        
        animation();
    }
}

// Initialize all chart components
new ModelCharts();
new TrainingProgressAnimation();
new MetricsAnimation();