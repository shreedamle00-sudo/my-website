// Live Emotion Detection Demo Simulation
class EmotionDetectionDemo {
    constructor() {
        this.isRecording = false;
        this.recordButton = document.getElementById('record-btn');
        this.statusDiv = document.getElementById('demo-status');
        this.resultsDiv = document.getElementById('demo-results');
        
        this.emotions = ['angry', 'calm', 'disgust', 'fearful', 'happy', 'neutral', 'sad', 'surprised'];
        this.emotionEmojis = {
            'angry': '😠',
            'calm': '😌',
            'disgust': '🤢',
            'fearful': '😨',
            'happy': '😊',
            'neutral': '😐',
            'sad': '😢',
            'surprised': '😲'
        };
        
        this.init();
    }
    
    init() {
        this.recordButton.addEventListener('click', () => {
            if (!this.isRecording) {
                this.startRecording();
            }
        });
    }
    
    async startRecording() {
        this.isRecording = true;
        this.recordButton.disabled = true;
        this.recordButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Recording...';
        this.recordButton.classList.add('opacity-50');
        
        this.statusDiv.textContent = 'Recording for 3 seconds... Speak now!';
        
        // Show results container
        this.resultsDiv.classList.remove('hidden');
        
        // Simulate audio metrics during recording
        this.simulateAudioMetrics();
        
        // Simulate 3-second recording
        setTimeout(() => {
            this.processRecording();
        }, 3000);
    }
    
    simulateAudioMetrics() {
        const audioLevel = document.getElementById('audio-level');
        const energyLevel = document.getElementById('energy-level');
        const zcrLevel = document.getElementById('zcr-level');
        
        // Simulate realistic audio metrics based on actual RAVDESS data ranges
        const maxAudio = (Math.random() * 0.35 + 0.05).toFixed(3); // 0.05 to 0.40 (realistic range)
        const energy = (Math.random() * 0.025 + 0.008).toFixed(4); // 0.008 to 0.033 (RMS energy range)
        const zcr = (Math.random() * 0.08 + 0.09).toFixed(4); // 0.09 to 0.17 (ZCR typical range)
        
        audioLevel.textContent = maxAudio;
        energyLevel.textContent = energy;
        zcrLevel.textContent = zcr;
        
        // More accurate feedback based on actual model thresholds
        const audioFloat = parseFloat(maxAudio);
        if (audioFloat < 0.01) {
            this.statusDiv.innerHTML = 'Recording... <span class="text-red-300">❌ Audio too low - check microphone!</span>';
        } else if (audioFloat < 0.05) {
            this.statusDiv.innerHTML = 'Recording... <span class="text-yellow-300">⚠️ Low audio - speak louder for better detection</span>';
        } else if (audioFloat > 0.3) {
            this.statusDiv.innerHTML = 'Recording... <span class="text-orange-300">🔊 High volume detected - good signal</span>';
        } else {
            this.statusDiv.innerHTML = 'Recording... <span class="text-green-300">✅ Optimal audio level detected</span>';
        }
    }
    
    processRecording() {
        this.statusDiv.textContent = 'Processing audio features...';
        
        // Simulate feature extraction processing time
        setTimeout(() => {
            this.statusDiv.innerHTML = 'Extracting 60D feature vector... <span class="text-blue-300">(MFCCs, Chroma, ZCR, Spectral Contrast)</span>';
            
            setTimeout(() => {
                this.statusDiv.innerHTML = 'Applying StandardScaler normalization... <span class="text-purple-300">(mean=0, std=1)</span>';
                
                setTimeout(() => {
                    this.statusDiv.innerHTML = 'Running MLPClassifier inference... <span class="text-green-300">(256→128→64→8 neurons)</span>';
                    
                    setTimeout(() => {
                        this.predictEmotion();
                    }, 500);
                }, 400);
            }, 300);
        }, 500);
    }
    
    predictEmotion() {
        // Simulate emotion prediction with realistic probabilities
        const predictions = this.generateRealisticPredictions();
        
        // Sort by probability
        const sortedPredictions = Object.entries(predictions)
            .sort(([,a], [,b]) => b - a);
        
        // Display predicted emotion with more detailed feedback
        const topEmotion = sortedPredictions[0][0];
        const topProbability = sortedPredictions[0][1];
        const secondProbability = sortedPredictions[1][1];
        
        const emotionResult = document.getElementById('emotion-result');
        emotionResult.innerHTML = `${this.emotionEmojis[topEmotion]} ${topEmotion.toUpperCase()}`;
        
        // More nuanced confidence analysis based on actual model behavior
        if (topProbability < 0.3) {
            emotionResult.innerHTML += '<br><span class="text-sm text-red-300">❌ Very low confidence - model is highly uncertain</span>';
        } else if (topProbability < 0.4) {
            emotionResult.innerHTML += '<br><span class="text-sm text-yellow-300">⚠️ Low confidence - consider speaking more expressively</span>';
        } else if (topProbability - secondProbability < 0.1) {
            emotionResult.innerHTML += '<br><span class="text-sm text-orange-300">🤔 Close prediction - model detected similar emotions</span>';
        } else if (topProbability > 0.8) {
            emotionResult.innerHTML += '<br><span class="text-sm text-green-300">✅ High confidence - clear emotional expression detected</span>';
        }
        
        // Display confidence bars
        this.displayConfidenceBars(sortedPredictions.slice(0, 3));
        
        // Reset button
        this.resetRecordButton();
        
        this.statusDiv.textContent = 'Prediction complete! Click to record again.';
    }
    
    generateRealisticPredictions() {
        // Generate predictions based on actual confusion matrix and model behavior
        const predictions = {};
        
        // Emotion-specific base probabilities (based on actual model performance)
        const emotionWeights = {
            'angry': 0.15,     // Often confused with disgust
            'calm': 0.20,      // Best performing emotion (87% recall)
            'disgust': 0.12,   // Often confused with angry
            'fearful': 0.13,   // Moderate performance
            'happy': 0.10,     // Lower performance, confused with surprised
            'neutral': 0.08,   // Class imbalance, conservative predictions
            'sad': 0.12,       // Moderate performance
            'surprised': 0.18  // Second best performing (82% recall)
        };
        
        // Add realistic noise and dominant prediction
        this.emotions.forEach(emotion => {
            const baseProb = emotionWeights[emotion] || 0.1;
            predictions[emotion] = baseProb + (Math.random() - 0.5) * 0.1;
        });
        
        // Select 1-2 dominant emotions based on model patterns
        const dominantEmotion = this.selectDominantEmotion();
        predictions[dominantEmotion] = Math.random() * 0.5 + 0.3; // 30-80%
        
        // Add confusion patterns (based on actual confusion matrix)
        this.addConfusionPatterns(predictions, dominantEmotion);
        
        // Normalize to sum to 1
        const total = Object.values(predictions).reduce((sum, prob) => sum + prob, 0);
        Object.keys(predictions).forEach(emotion => {
            predictions[emotion] = Math.max(0.001, predictions[emotion] / total);
        });
        
        return predictions;
    }
    
    selectDominantEmotion() {
        // Weight selection based on actual model performance
        const performanceWeights = {
            'calm': 0.25,      // 87% recall - most reliable
            'surprised': 0.22, // 82% recall - very good  
            'angry': 0.15,     // 66% recall - decent
            'fearful': 0.13,   // 67% recall - decent
            'sad': 0.10,       // 58% recall - moderate
            'disgust': 0.08,   // 58% recall - moderate
            'happy': 0.05,     // 49% recall - challenging
            'neutral': 0.02    // 42% recall - most challenging
        };
        
        const rand = Math.random();
        let cumulative = 0;
        
        for (const [emotion, weight] of Object.entries(performanceWeights)) {
            cumulative += weight;
            if (rand <= cumulative) {
                return emotion;
            }
        }
        return 'neutral'; // fallback
    }
    
    addConfusionPatterns(predictions, dominantEmotion) {
        // Add realistic confusion patterns from actual confusion matrix
        const confusionPairs = {
            'angry': ['disgust', 'neutral'],           // Angry often confused with disgust
            'calm': ['neutral', 'sad'],                // Calm sometimes confused with neutral
            'disgust': ['angry', 'surprised'],         // Disgust confused with angry
            'fearful': ['sad', 'angry'],              // Fearful confused with sad
            'happy': ['surprised', 'calm'],            // Happy confused with surprised
            'neutral': ['calm', 'sad'],               // Neutral confused with calm/sad
            'sad': ['fearful', 'neutral'],            // Sad confused with fearful
            'surprised': ['happy', 'disgust']          // Surprised confused with happy
        };
        
        const confusedEmotions = confusionPairs[dominantEmotion] || [];
        confusedEmotions.forEach(emotion => {
            if (Math.random() < 0.3) { // 30% chance of confusion
                predictions[emotion] += Math.random() * 0.2; // Boost confused emotion
            }
        });
    }
    
    displayConfidenceBars(topPredictions) {
        const confidenceBars = document.getElementById('confidence-bars');
        confidenceBars.innerHTML = '';
        
        topPredictions.forEach(([emotion, probability]) => {
            const barContainer = document.createElement('div');
            barContainer.className = 'flex items-center space-x-3';
            
            const barLength = Math.round(probability * 20);
            const filledBar = '█'.repeat(barLength);
            const emptyBar = '░'.repeat(20 - barLength);
            
            barContainer.innerHTML = `
                <div class="w-20 text-right text-sm font-medium">
                    ${this.emotionEmojis[emotion]} ${emotion}
                </div>
                <div class="flex-1 font-mono text-sm text-blue-300">
                    ${filledBar}${emptyBar}
                </div>
                <div class="w-16 text-right text-sm font-bold text-accent">
                    ${(probability * 100).toFixed(1)}%
                </div>
            `;
            
            confidenceBars.appendChild(barContainer);
        });
    }
    
    resetRecordButton() {
        this.recordButton.disabled = false;
        this.recordButton.innerHTML = '<i class="fas fa-microphone mr-2"></i>Record Again';
        this.recordButton.classList.remove('opacity-50');
        this.isRecording = false;
    }
}

// Initialize demo when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new EmotionDetectionDemo();
});