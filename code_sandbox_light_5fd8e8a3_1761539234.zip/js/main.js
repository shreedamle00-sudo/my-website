// Main JavaScript functionality for the Emotion Recognition website
class EmotionRecognitionApp {
    constructor() {
        this.init();
    }
    
    init() {
        this.setupNavigation();
        this.setupScrollEffects();
        this.setupCodeToggle();
        this.setupMobileMenu();
        this.setupSmoothScrolling();
        this.setupAnimationTriggers();
    }
    
    // Navigation functionality
    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav-link, .mobile-nav-link');
        const sections = document.querySelectorAll('section[id]');
        
        // Highlight active nav item on scroll
        window.addEventListener('scroll', () => {
            let currentSection = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop - 100;
                const sectionHeight = section.clientHeight;
                
                if (window.pageYOffset >= sectionTop && 
                    window.pageYOffset < sectionTop + sectionHeight) {
                    currentSection = section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('text-primary', 'font-semibold');
                link.classList.add('text-gray-700');
                
                if (link.getAttribute('href') === `#${currentSection}`) {
                    link.classList.remove('text-gray-700');
                    link.classList.add('text-primary', 'font-semibold');
                }
            });
        });
    }
    
    // Smooth scrolling for anchor links
    setupSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                
                if (target) {
                    const targetPosition = target.offsetTop - 80; // Account for fixed nav
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    const mobileMenu = document.getElementById('mobile-menu');
                    if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                    }
                }
            });
        });
    }
    
    // Mobile menu toggle
    setupMobileMenu() {
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
                
                const icon = mobileMenuBtn.querySelector('i');
                if (mobileMenu.classList.contains('hidden')) {
                    icon.className = 'fas fa-bars text-xl';
                } else {
                    icon.className = 'fas fa-times text-xl';
                }
            });
            
            // Close mobile menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!mobileMenuBtn.contains(e.target) && !mobileMenu.contains(e.target)) {
                    mobileMenu.classList.add('hidden');
                    const icon = mobileMenuBtn.querySelector('i');
                    icon.className = 'fas fa-bars text-xl';
                }
            });
        }
    }
    
    // Code section toggle functionality
    setupCodeToggle() {
        const codeToggles = document.querySelectorAll('.code-toggle');
        
        codeToggles.forEach(toggle => {
            toggle.addEventListener('click', () => {
                const targetId = toggle.getAttribute('data-target');
                const targetElement = document.getElementById(targetId);
                const icon = toggle.querySelector('i');
                
                if (targetElement) {
                    if (targetElement.classList.contains('hidden')) {
                        targetElement.classList.remove('hidden');
                        icon.style.transform = 'rotate(180deg)';
                        
                        // Animate the code block appearance
                        targetElement.style.maxHeight = '0';
                        targetElement.style.overflow = 'hidden';
                        targetElement.style.transition = 'max-height 0.3s ease-out';
                        
                        setTimeout(() => {
                            targetElement.style.maxHeight = targetElement.scrollHeight + 'px';
                        }, 10);
                        
                        setTimeout(() => {
                            targetElement.style.maxHeight = '';
                            targetElement.style.overflow = '';
                            targetElement.style.transition = '';
                        }, 300);
                    } else {
                        targetElement.style.maxHeight = targetElement.scrollHeight + 'px';
                        targetElement.style.overflow = 'hidden';
                        targetElement.style.transition = 'max-height 0.3s ease-in';
                        
                        setTimeout(() => {
                            targetElement.style.maxHeight = '0';
                        }, 10);
                        
                        setTimeout(() => {
                            targetElement.classList.add('hidden');
                            targetElement.style.maxHeight = '';
                            targetElement.style.overflow = '';
                            targetElement.style.transition = '';
                        }, 300);
                        
                        icon.style.transform = 'rotate(0deg)';
                    }
                }
            });
        });
    }
    
    // Scroll-triggered animations
    setupScrollEffects() {
        // Fade in animation for cards
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fade-in-up');
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        const animatedElements = document.querySelectorAll(
            '.feature-card, .emotion-card, .metric-card, .chart-container, .code-section'
        );
        
        animatedElements.forEach(el => {
            observer.observe(el);
        });
    }
    
    // Setup animation triggers
    setupAnimationTriggers() {
        // Add staggered animation for emotion cards
        const emotionCards = document.querySelectorAll('.emotion-card');
        
        const emotionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const cards = Array.from(emotionCards);
                    cards.forEach((card, index) => {
                        setTimeout(() => {
                            card.style.transform = 'translateY(0)';
                            card.style.opacity = '1';
                        }, index * 100);
                    });
                }
            });
        }, { threshold: 0.2 });
        
        if (emotionCards.length > 0) {
            // Initially hide cards
            emotionCards.forEach(card => {
                card.style.transform = 'translateY(20px)';
                card.style.opacity = '0';
                card.style.transition = 'transform 0.6s ease, opacity 0.6s ease';
            });
            
            emotionObserver.observe(emotionCards[0]);
        }
    }
    
    // Utility function to create typing animation
    typeAnimation(element, text, speed = 50) {
        let i = 0;
        const timer = setInterval(() => {
            if (i < text.length) {
                element.textContent += text.charAt(i);
                i++;
            } else {
                clearInterval(timer);
            }
        }, speed);
    }
    
    // Utility function to animate numbers
    animateNumber(element, target, duration = 2000) {
        let start = 0;
        const increment = target / (duration / 16);
        
        const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
                start = target;
                clearInterval(timer);
            }
            
            if (element.dataset.type === 'percentage') {
                element.textContent = start.toFixed(2) + '%';
            } else {
                element.textContent = Math.floor(start).toLocaleString();
            }
        }, 16);
    }
}

// Scroll progress indicator
class ScrollProgress {
    constructor() {
        this.createProgressBar();
        this.updateProgress();
    }
    
    createProgressBar() {
        const progressBar = document.createElement('div');
        progressBar.id = 'scroll-progress';
        progressBar.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: linear-gradient(to right, #3B82F6, #1E40AF);
            z-index: 9999;
            transition: width 0.1s ease;
        `;
        
        document.body.appendChild(progressBar);
    }
    
    updateProgress() {
        window.addEventListener('scroll', () => {
            const progressBar = document.getElementById('scroll-progress');
            const scrolled = (window.pageYOffset / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
            
            progressBar.style.width = scrolled + '%';
        });
    }
}

// Loading screen
class LoadingScreen {
    constructor() {
        this.createLoadingScreen();
    }
    
    createLoadingScreen() {
        const loader = document.createElement('div');
        loader.id = 'loading-screen';
        loader.innerHTML = `
            <div class="fixed inset-0 bg-white z-50 flex items-center justify-center">
                <div class="text-center">
                    <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                    <div class="text-lg font-semibold text-gray-700">Loading AI System...</div>
                </div>
            </div>
        `;
        
        document.body.appendChild(loader);
        
        // Remove loading screen when page is fully loaded
        window.addEventListener('load', () => {
            setTimeout(() => {
                loader.style.opacity = '0';
                loader.style.transition = 'opacity 0.5s ease';
                
                setTimeout(() => {
                    loader.remove();
                }, 500);
            }, 1000);
        });
    }
}

// Performance monitoring
class PerformanceMonitor {
    constructor() {
        this.init();
    }
    
    init() {
        // Monitor page load performance
        window.addEventListener('load', () => {
            if (window.performance && window.performance.navigation.type === 0) {
                const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;
                console.log(`Page loaded in ${loadTime}ms`);
            }
        });
        
        // Monitor scroll performance
        let ticking = false;
        
        window.addEventListener('scroll', () => {
            if (!ticking) {
                requestAnimationFrame(() => {
                    // Scroll-related performance optimizations
                    ticking = false;
                });
                ticking = true;
            }
        });
    }
}

// Initialize all components when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new EmotionRecognitionApp();
    new ScrollProgress();
    new LoadingScreen();
    new PerformanceMonitor();
});

// Add custom CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .animate-fade-in-up {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .animate-fade-in {
        animation: fadeInUp 0.8s ease forwards;
    }
    
    /* Smooth transitions for interactive elements */
    .feature-card, .emotion-card, .metric-card, .code-section {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .feature-card:hover, .emotion-card:hover, .metric-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .code-toggle i {
        transition: transform 0.3s ease;
    }
    
    /* Loading animations */
    @keyframes pulse {
        0%, 100% {
            opacity: 1;
        }
        50% {
            opacity: 0.5;
        }
    }
    
    .animate-pulse {
        animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
`;

document.head.appendChild(style);